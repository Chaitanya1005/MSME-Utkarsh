// Pure lead-update extraction from a transcript, kept independent of
// Express/Prisma so it is directly unit-testable (the same pattern as
// authorization.ts and branchUpdateStatus.ts).
//
// HONEST SCOPE NOTE (see docs/PHASE3_4_SCOPE.md "AI provider boundary"
// for the full explanation, and docs/VOICE_LEAD_UPDATE.md for this
// revision's specifics): this is a deterministic, rule-based extractor —
// lead-number/name matching plus phrase-pattern matching against the
// BM's own authorized leads — not a call to a large language model. What
// this DOES do, for real: split a transcript into clauses, resolve each
// clause to zero/one/many candidate leads from the BM's authorized list
// (by spoken lead number first, since spec requires the real database
// identifier to be primary — fallaaing back to customer name only when no
// number is spoken), extract a target pipeline stage from an ordered,
// negation-aware phrase dictionary, and flag genuine ambiguity rather
// than guessing.
//
// The provider boundary (services/providers/transcriptionProvider.ts) is
// what a real LLM-based extractor would plug into instead of this file,
// without changing anything in voiceUpdate.service.ts or the API
// contract — see that file's own header comment.

import { PipelineStage } from '../types/domain';

export interface AuthorizedLeadForExtraction {
  id: string;
  customerName: string;
  // The real, stable business identifier (spec: "the application should
  // not conceptually rely on customer names as the primary lead
  // identification mechanism... every lead should expose the same
  // stable identifier used by the database"). Nullable because Phase 1's
  // schema allows a lead with no source reference.
  sourceSrNo: string | null;
}

export type AmbiguityReason = 'NO_LEAD_MATCH' | 'MULTIPLE_LEAD_MATCH' | 'NO_STAGE_MATCH';

export interface ExtractedCandidate {
  rawClause: string;
  // The lead number as spoken/extracted from the clause, independent of
  // whether it resolved to a real lead — reported even on a NO_LEAD_MATCH
  // so the BM/RM can see exactly what number was heard.
  spokenLeadNumber: string | null;
  matchedLeadId: string | null;
  matchedLeadName: string | null;
  candidateLeadIds: string[]; // populated only when ambiguityReason === 'MULTIPLE_LEAD_MATCH'
  proposedStage: PipelineStage | null;
  remarks: string;
  ambiguityReason: AmbiguityReason | null;
}

// Ordered, most-specific-first. Negation/not-yet-happened phrases are
// checked BEFORE the generic affirmative keyword they'd otherwise
// collide with — e.g. "application bhejna ABHI BAAKI hai" (the
// application has NOT been sent yet) must resolve to CONTACTED, not
// APPLICATION, even though the word "application" is present; the same
// pattern applies to "contact karna baaki hai" (not yet contacted, stays
// INTERESTED) vs plain "contacted"/"contact kiya" (CONTACTED). This
// ordering is the actual safety-relevant part of this file — a naive
// single-keyword match would silently invert these two demo phrases.
const STAGE_PHRASE_RULES: Array<{ stage: PipelineStage; patterns: RegExp[] }> = [
  { stage: 'CONVERSION', patterns: [/disburs/i, /\bconvert/i, /loan (is |has )?closed/i] },
  {
    stage: 'APPROVAL',
    patterns: [/sanction/i, /application[^.]*approv/i, /approv[^.]*application/i, /\bapprov/i],
  },
  // "application bhejna ... baaki" / "baaki ... bhejna" = the application
  // has explicitly NOT been sent yet -> the lead is still at CONTACTED,
  // not APPLICATION. Checked before the generic APPLICATION rule below.
  { stage: 'CONTACTED', patterns: [/bhejna[^.]*baaki/i, /baaki[^.]*bhejna/i] },
  { stage: 'APPLICATION', patterns: [/application/i, /\bapplied\b/i, /\bsubmit/i] },
  // "contact karna ... baaki" / "abhi contact karna baaki" = not yet
  // contacted -> stays INTERESTED. Checked before the generic CONTACTED
  // rule below.
  { stage: 'INTERESTED', patterns: [/contact[^.]*karna[^.]*baaki/i, /baaki[^.]*contact[^.]*karna/i] },
  { stage: 'CONTACTED', patterns: [/\bcontact(ed)?\b/i, /\bcall(ed)?\b/i, /\bspoke\b/i, /baat (ho|hui)/i] },
  { stage: 'INTERESTED', patterns: [/interest/i] },
];

// Matches "lead 101", "lead number 101", "lead no 101", "lead no. 101",
// "lead #101" — case-insensitive, tolerant of the filler words a BM is
// likely to actually say.
const LEAD_NUMBER_PATTERN = /\blead\s*(?:number|no\.?|#)?\s*(\d+)\b/i;

function splitIntoClauses(transcript: string): string[] {
  return transcript
    .split(/[.\n]+/)
    .map((c) => c.trim())
    .filter((c) => c.length > 0);
}

function findStage(clause: string): PipelineStage | null {
  for (const entry of STAGE_PHRASE_RULES) {
    if (entry.patterns.some((p) => p.test(clause))) {
      return entry.stage;
    }
  }
  return null;
}

function extractSpokenLeadNumber(clause: string): string | null {
  const match = clause.match(LEAD_NUMBER_PATTERN);
  return match ? match[1] : null;
}

// Matches a clause against authorized leads by customer name substring
// (case-insensitive, first-name-tolerant — "Sharma" matches "Anil
// Sharma"). Used only as a fallback when the clause names no lead
// number. Never matches leads outside the provided authorized list,
// which the caller must have already scoped to the BM's own branch.
function findMatchingLeadsByName(
  clause: string,
  leads: AuthorizedLeadForExtraction[]
): AuthorizedLeadForExtraction[] {
  const lowerClause = clause.toLowerCase();
  return leads.filter((lead) => {
    const nameParts = lead.customerName.toLowerCase().split(/\s+/);
    return nameParts.some((part) => part.length >= 3 && lowerClause.includes(part));
  });
}

function stripMatchedTokens(clause: string, leadName: string | null): string {
  let remarks = clause;
  if (leadName) {
    for (const part of leadName.split(/\s+/)) {
      if (part.length >= 3) {
        remarks = remarks.replace(new RegExp(part, 'gi'), '').trim();
      }
    }
  }
  remarks = remarks.replace(LEAD_NUMBER_PATTERN, '').trim();
  return remarks.replace(/\s{2,}/g, ' ').trim() || clause.trim();
}

export function extractUpdateCandidates(
  transcript: string,
  authorizedLeads: AuthorizedLeadForExtraction[]
): ExtractedCandidate[] {
  const clauses = splitIntoClauses(transcript);

  return clauses.map((rawClause) => {
    const spokenLeadNumber = extractSpokenLeadNumber(rawClause);
    const stage = findStage(rawClause);

    // Lead number takes priority (spec: the real database identifier is
    // the primary matching mechanism, not the customer name) — if a
    // number was spoken, ONLY match against it; do not fall back to a
    // name match even if a name also happens to appear in the same
    // clause, since the number is the more precise, explicitly-stated
    // signal.
    const matches = spokenLeadNumber
      ? authorizedLeads.filter((l) => l.sourceSrNo === spokenLeadNumber)
      : findMatchingLeadsByName(rawClause, authorizedLeads);

    if (matches.length === 0) {
      return {
        rawClause,
        spokenLeadNumber,
        matchedLeadId: null,
        matchedLeadName: null,
        candidateLeadIds: [],
        proposedStage: stage,
        remarks: rawClause,
        ambiguityReason: 'NO_LEAD_MATCH',
      };
    }

    if (matches.length > 1) {
      return {
        rawClause,
        spokenLeadNumber,
        matchedLeadId: null,
        matchedLeadName: null,
        candidateLeadIds: matches.map((m) => m.id),
        proposedStage: stage,
        remarks: rawClause,
        ambiguityReason: 'MULTIPLE_LEAD_MATCH',
      };
    }

    const lead = matches[0];
    if (!stage) {
      return {
        rawClause,
        spokenLeadNumber,
        matchedLeadId: lead.id,
        matchedLeadName: lead.customerName,
        candidateLeadIds: [],
        proposedStage: null,
        remarks: stripMatchedTokens(rawClause, lead.customerName),
        ambiguityReason: 'NO_STAGE_MATCH',
      };
    }

    return {
      rawClause,
      spokenLeadNumber,
      matchedLeadId: lead.id,
      matchedLeadName: lead.customerName,
      candidateLeadIds: [],
      proposedStage: stage,
      remarks: stripMatchedTokens(rawClause, lead.customerName),
      ambiguityReason: null,
    };
  });
}
